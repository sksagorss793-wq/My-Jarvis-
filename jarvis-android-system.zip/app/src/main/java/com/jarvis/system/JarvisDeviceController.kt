package com.jarvis.system

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import androidx.core.content.ContextCompat

class JarvisDeviceController(private val context: Context) {

    private var torchEnabled = false

    fun toggleFlashlight(): Boolean {
        val next = !torchEnabled
        if (setFlashlight(next)) {
            torchEnabled = next
        }
        return torchEnabled
    }

    fun getBatteryPercent(): Int {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }

    fun getPhonebookContactsSummary(limit: Int = 25): org.json.JSONArray {
        val arr = org.json.JSONArray()
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return arr
        }
        try {
            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null,
                null,
                null
            )?.use { cursor ->
                val seen = HashSet<String>()
                val nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (cursor.moveToNext() && arr.length() < limit) {
                    val name = if (nameIdx >= 0) cursor.getString(nameIdx)?.trim().orEmpty() else ""
                    val num = if (numIdx >= 0) cursor.getString(numIdx)?.trim().orEmpty() else ""
                    if (name.isNotBlank() && num.isNotBlank() && seen.add(name.lowercase())) {
                        arr.put(org.json.JSONObject().apply {
                            put("name", name)
                            put("phone", num)
                        })
                    }
                }
            }
        } catch (_: Exception) {
        }
        return arr
    }

    fun handleLocalSystemCommand(userText: String): String? {
        val lower = userText.lowercase().trim()

        // Flashlight control
        if (lower.contains("flashlight on") || lower.contains("torch on") ||
            (lower.contains("টর্চ") && (lower.contains("চালু") || lower.contains("অন") || lower.contains("জ্বালাও")))
        ) {
            return if (setFlashlight(true)) {
                torchEnabled = true
                if (isBangla(userText)) "ফ্ল্যাশলাইট চালু করেছি।" else "Flashlight turned on."
            } else {
                if (isBangla(userText)) "ফ্ল্যাশলাইট চালু করা যায়নি।" else "Could not turn on flashlight."
            }
        }

        if (lower.contains("flashlight off") || lower.contains("torch off") ||
            (lower.contains("টর্চ") && (lower.contains("বন্ধ") || lower.contains("অফ") || lower.contains("নেভাও")))
        ) {
            return if (setFlashlight(false)) {
                torchEnabled = false
                if (isBangla(userText)) "ফ্ল্যাশলাইট বন্ধ করেছি।" else "Flashlight turned off."
            } else {
                if (isBangla(userText)) "ফ্ল্যাশলাইট বন্ধ করা যায়নি।" else "Could not turn off flashlight."
            }
        }

        // Battery level
        if (lower.contains("battery") || lower.contains("ব্যাটারি") || lower.contains("চার্জ কত")) {
            val pct = getBatteryPercent()
            return if (isBangla(userText)) "আপনার ফোনে এখন $pct% চার্জ আছে।" else "Your phone battery is at $pct%."
        }

        // Quick Wi-Fi / Bluetooth settings shortcuts
        if (lower == "wifi settings" || lower == "open wifi" || lower == "ওয়াইফাই সেটিংস") {
            val intent = Intent(Settings.ACTION_WIFI_SETTINGS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            context.startActivity(intent)
            return if (isBangla(userText)) "Wi-Fi সেটিংস খুলেছি।" else "Opened Wi-Fi settings."
        }

        if (lower == "bluetooth settings" || lower == "open bluetooth" || lower == "ব্লুটুথ সেটিংস") {
            val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            context.startActivity(intent)
            return if (isBangla(userText)) "Bluetooth সেটিংস খুলেছি।" else "Opened Bluetooth settings."
        }

        // Open installed app by name
        val openAppMatch = Regex("^(?:open|launch)\s+([a-zA-Z0-9 ._-]+)$", RegexOption.IGNORE_CASE).find(userText.trim())
        if (openAppMatch != null) {
            val appQuery = openAppMatch.groupValues[1].trim()
            if (launchInstalledApp(appQuery)) {
                return "Opening $appQuery."
            }
        }

        return null
    }

    fun executeTool(name: String, argsJson: org.json.JSONObject): String {
        return when (name) {
            "call_number" -> {
                val rawNum = argsJson.optString("number").ifBlank { argsJson.optString("contactName") }
                val number = resolvePhoneNumber(rawNum).replace(Regex("[^0-9+]"), "")
                if (number.isBlank()) return "No valid number found."
                val hasCallPerm = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.CALL_PHONE
                ) == PackageManager.PERMISSION_GRANTED
                val action = if (hasCallPerm) Intent.ACTION_CALL else Intent.ACTION_DIAL
                val intent = Intent(action, Uri.parse("tel:$number")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                if (hasCallPerm) "Calling $number now." else "Dialer opened for $number."
            }
            "send_sms" -> {
                val number = resolvePhoneNumber(argsJson.optString("number")).replace(Regex("[^0-9+]"), "")
                val text = argsJson.optString("text")
                if (number.isBlank()) return "No valid number found."
                val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")).apply {
                    putExtra("sms_body", text)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                "SMS screen opened for $number."
            }
            "send_whatsapp" -> {
                val number = resolvePhoneNumber(argsJson.optString("number")).replace(Regex("[^0-9]"), "")
                val text = Uri.encode(argsJson.optString("text"))
                val url = if (number.isNotBlank()) "https://wa.me/$number?text=$text" else "https://wa.me/?text=$text"
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                "WhatsApp opened."
            }
            "open_link" -> {
                val url = argsJson.optString("url")
                if (url.startsWith("https://")) {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                    "Opened link."
                } else {
                    "Only https links supported."
                }
            }
            "set_timer" -> {
                val sec = argsJson.optInt("seconds", 60).coerceIn(1, 86400)
                val label = argsJson.optString("label", "Jarvis Timer")
                val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                    putExtra(AlarmClock.EXTRA_LENGTH, sec)
                    putExtra(AlarmClock.EXTRA_MESSAGE, label)
                    putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    context.startActivity(intent)
                    "System timer set for $sec seconds."
                } catch (_: Exception) {
                    "Timer intent not available on this device."
                }
            }
            "remember" -> {
                val fact = argsJson.optString("fact")
                JarvisPrefs(context).addFact(fact)
                "Saved to memory."
            }
            else -> "Completed $name."
        }
    }

    private fun resolvePhoneNumber(input: String): String {
        val cleaned = input.trim()
        val digitsOnly = cleaned.replace(Regex("[^0-9+]"), "")
        if (digitsOnly.length >= 6) return digitsOnly

        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return cleaned
        }

        try {
            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null,
                null,
                null
            )?.use { cursor ->
                val nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (cursor.moveToNext()) {
                    val name = if (nameIdx >= 0) cursor.getString(nameIdx).orEmpty() else ""
                    val num = if (numIdx >= 0) cursor.getString(numIdx).orEmpty() else ""
                    if (name.contains(cleaned, ignoreCase = true) && num.isNotBlank()) {
                        return num
                    }
                }
            }
        } catch (_: Exception) {
        }
        return cleaned
    }

    fun launchInstalledApp(query: String): Boolean {
        val pm = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val apps = pm.queryIntentActivities(mainIntent, 0)
        val match = apps.firstOrNull { info ->
            val label = info.loadLabel(pm).toString()
            label.equals(query, ignoreCase = true) || label.contains(query, ignoreCase = true)
        } ?: return false

        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launch)
        return true
    }

    fun setFlashlight(on: Boolean): Boolean {
        return try {
            val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = cm.cameraIdList.firstOrNull { id ->
                cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return false
            cm.setTorchMode(cameraId, on)
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun isBangla(text: String): Boolean = text.any { it in '\u0980'..'\u09FF' }
}
