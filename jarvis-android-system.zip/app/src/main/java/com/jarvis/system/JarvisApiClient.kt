package com.jarvis.system

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.Date
import java.util.concurrent.TimeUnit

class JarvisApiClient(private val context: Context) {
    private val prefs = JarvisPrefs(context)
    private val deviceController = JarvisDeviceController(context)
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .build()

    private val history = JSONArray()

    suspend fun askJarvis(userText: String): String = withContext(Dispatchers.IO) {
        val localReply = deviceController.handleLocalSystemCommand(userText)
        if (localReply != null) {
            return@withContext localReply
        }

        // Keep conversation bounded cleanly
        if (history.length() > 24) {
            val trimmed = JSONArray()
            val start = history.length() - 16
            var foundUser = false
            for (i in start until history.length()) {
                val item = history.optJSONObject(i) ?: continue
                if (!foundUser && item.optString("role") != "user") continue
                foundUser = true
                trimmed.put(item)
            }
            while (history.length() > 0) history.remove(0)
            for (i in 0 until trimmed.length()) history.put(trimmed.get(i))
        }

        val userMsg = JSONObject().apply {
            put("role", "user")
            put("parts", JSONArray().put(JSONObject().put("text", userText)))
        }
        history.put(userMsg)

        var finalReply = ""
        for (step in 0 until 5) {
            val payload = JSONObject().apply {
                put("contents", history)
                put("facts", JSONArray(prefs.getFacts()))
                put("contacts", deviceController.getPhonebookContactsSummary())
                put("lang", prefs.language)
                put("thinkingMode", "fast")
                put("clientTime", Date().toString())
            }

            val req = Request.Builder()
                .url("${prefs.serverUrl}/api/chat")
                .post(payload.toString().toRequestBody("application/json".toMediaType()))
                .build()

            http.newCall(req).execute().use { res ->
                val raw = res.body?.string().orEmpty()
                val json = try {
                    JSONObject(raw.ifBlank { "{}" })
                } catch (_: Exception) {
                    JSONObject()
                }
                if (!res.isSuccessful) {
                    throw IllegalStateException(json.optString("error", "HTTP ${res.code}"))
                }

                val modelContent = json.optJSONObject("modelContent")
                if (modelContent != null) {
                    history.put(modelContent)
                }

                val calls = json.optJSONArray("functionCalls")
                if (calls != null && calls.length() > 0) {
                    val responseParts = JSONArray()
                    for (i in 0 until calls.length()) {
                        val call = calls.getJSONObject(i)
                        val name = call.optString("name")
                        val args = call.optJSONObject("args") ?: JSONObject()
                        val result = deviceController.executeTool(name, args)
                        val fr = JSONObject().apply {
                            put("functionResponse", JSONObject().apply {
                                if (call.has("id")) put("id", call.optString("id"))
                                put("name", name)
                                put("response", JSONObject().put("response", result))
                            })
                        }
                        responseParts.put(fr)
                    }
                    history.put(JSONObject().apply {
                        put("role", "user")
                        put("parts", responseParts)
                    })
                } else {
                    finalReply = json.optString("text", "").trim()
                    return@withContext finalReply.ifBlank { "কাজটি সম্পন্ন হয়েছে।" }
                }
            }
        }
        finalReply.ifBlank { "দুঃখিত, উত্তর তৈরি করা যায়নি।" }
    }

    suspend fun fetchNaturalTtsWav(text: String): ByteArray? = withContext(Dispatchers.IO) {
        return@withContext try {
            val payload = JSONObject().apply {
                put("text", text.take(900))
                put("voiceName", prefs.voicePersona)
                put("lang", prefs.language)
            }
            val req = Request.Builder()
                .url("${prefs.serverUrl}/api/tts")
                .post(payload.toString().toRequestBody("application/json".toMediaType()))
                .build()

            http.newCall(req).execute().use { res ->
                if (!res.isSuccessful) return@withContext null
                val json = JSONObject(res.body?.string().orEmpty())
                val b64 = json.optString("audioBase64", "")
                if (b64.isBlank()) null else android.util.Base64.decode(b64, android.util.Base64.DEFAULT)
            }
        } catch (_: Exception) {
            null
        }
    }

    suspend fun generateAwayReply(
        visitorName: String,
        contact: String,
        channel: String,
        message: String
    ): String? = withContext(Dispatchers.IO) {
        return@withContext try {
            val payload = JSONObject().apply {
                put("visitorName", visitorName)
                put("contact", contact)
                put("channel", channel)
                put("message", message)
                put("lang", prefs.language)
            }
            val req = Request.Builder()
                .url("${prefs.serverUrl}/api/desk/reply")
                .post(payload.toString().toRequestBody("application/json".toMediaType()))
                .build()

            http.newCall(req).execute().use { res ->
                if (!res.isSuccessful) return@withContext null
                val json = JSONObject(res.body?.string().orEmpty())
                json.optString("reply", "").trim().ifBlank { null }
            }
        } catch (_: Exception) {
            null
        }
    }

    suspend fun syncAwayEnabled(enabled: Boolean) = withContext(Dispatchers.IO) {
        try {
            val payload = JSONObject().apply { put("enabled", enabled) }
            val req = Request.Builder()
                .url("${prefs.serverUrl}/api/away")
                .post(payload.toString().toRequestBody("application/json".toMediaType()))
                .build()
            http.newCall(req).execute().close()
        } catch (_: Exception) {
        }
    }
}
