package com.jarvis.system

import android.os.Bundle
import android.view.Gravity
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class JarvisAssistantActivity : AppCompatActivity() {
    private lateinit var apiClient: JarvisApiClient
    private lateinit var voiceManager: JarvisVoiceManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        apiClient = JarvisApiClient(this)
        voiceManager = JarvisVoiceManager(this, apiClient)

        val tv = TextView(this).apply {
            text = "Jarvis শুনছে…"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(0xFFD4F1FF.toInt())
            setBackgroundColor(0xFF0B1520.toInt())
            setPadding(48, 48, 48, 48)
        }
        setContentView(tv)

        voiceManager.startSingleListen(
            onListening = { tv.text = "বলুন, শুনছি…" },
            onResult = { spoken ->
                tv.text = spoken
                CoroutineScope(Dispatchers.Main).launch {
                    val reply = try {
                        apiClient.askJarvis(spoken)
                    } catch (e: Exception) {
                        e.message ?: "Error"
                    }
                    tv.text = reply
                    voiceManager.speak(reply) {
                        finish()
                    }
                }
            },
            onError = { err ->
                tv.text = err
            }
        )
    }

    override fun onDestroy() {
        super.onDestroy()
        voiceManager.destroy()
    }
}
