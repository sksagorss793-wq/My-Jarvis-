package com.jarvis.system

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class JarvisOverlayService : Service() {
    companion object {
        @Volatile
        var isRunning: Boolean = false
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val uiHandler = Handler(Looper.getMainLooper())
    private lateinit var windowManager: WindowManager
    private var orbView: ImageView? = null
    private var bubbleView: TextView? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private lateinit var apiClient: JarvisApiClient
    private lateinit var voiceManager: JarvisVoiceManager
    private var isBusy = false

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        apiClient = JarvisApiClient(this)
        voiceManager = JarvisVoiceManager(this, apiClient)
        startForegroundNotification()
        if (Settings.canDrawOverlays(this)) {
            attachFloatingOrb()
        }
    }

    private fun startForegroundNotification() {
        val channelId = "jarvis_overlay_channel"
        val nm = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            channelId,
            "Jarvis System Assistant",
            NotificationManager.IMPORTANCE_LOW
        )
        nm.createNotificationChannel(channel)

        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Jarvis সিস্টেমে চালু আছে")
            .setContentText("যেকোনো স্ক্রিনে ভাসমান অর্বে ট্যাপ করে কথা বলুন")
            .setSmallIcon(R.drawable.ic_jarvis_orb)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val hasMic = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
            val fgsType = if (hasMic) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            } else {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            }
            startForeground(101, notification, fgsType)
        } else {
            startForeground(101, notification)
        }
    }

    private fun attachFloatingOrb() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val density = resources.displayMetrics.density
        val sizePx = (64 * density).toInt()

        val params = WindowManager.LayoutParams(
            sizePx,
            sizePx,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (20 * density).toInt()
            y = (220 * density).toInt()
        }

        val bParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (96 * density).toInt()
            y = (224 * density).toInt()
        }
        bubbleParams = bParams

        val bubble = TextView(this).apply {
            visibility = View.GONE
            maxWidth = (240 * density).toInt()
            setTextColor(Color.parseColor("#E3F5FF"))
            textSize = 13f
            setPadding((14 * density).toInt(), (10 * density).toInt(), (14 * density).toInt(), (10 * density).toInt())
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#EB081420"))
                cornerRadius = 16 * density
                setStroke((1 * density).toInt(), Color.parseColor("#662BD3FF"))
            }
            setOnClickListener { visibility = View.GONE }
        }
        windowManager.addView(bubble, bParams)
        bubbleView = bubble

        val orb = ImageView(this).apply {
            setImageResource(R.drawable.ic_jarvis_orb)
            elevation = 12f
        }

        var initialX = 0
        var initialY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false

        orb.setOnTouchListener { _: View, event: MotionEvent ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) moved = true
                    params.x = initialX + dx
                    params.y = initialY + dy
                    windowManager.updateViewLayout(orb, params)
                    bParams.x = params.x + sizePx + (10 * density).toInt()
                    bParams.y = params.y
                    windowManager.updateViewLayout(bubble, bParams)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        triggerVoiceTurn(orb)
                    }
                    true
                }
                else -> false
            }
        }

        orb.setOnLongClickListener {
            val intent = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
            true
        }

        windowManager.addView(orb, params)
        orbView = orb
    }

    private fun showBubble(text: String, autoHideMs: Long = 0L) {
        uiHandler.removeCallbacksAndMessages(null)
        bubbleView?.apply {
            this.text = text
            visibility = View.VISIBLE
            if (autoHideMs > 0L) {
                uiHandler.postDelayed({ visibility = View.GONE }, autoHideMs)
            }
        }
    }

    private fun resetOrb(orb: ImageView) {
        isBusy = false
        orb.alpha = 1f
        orb.scaleX = 1f
        orb.scaleY = 1f
    }

    private fun triggerVoiceTurn(orb: ImageView) {
        if (isBusy) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            showBubble("মাইক্রোফোন অনুমতি দিতে Jarvis অ্যাপটি খুলুন", 4000L)
            return
        }

        isBusy = true
        orb.alpha = 0.75f
        showBubble("শুনছি…")

        voiceManager.startSingleListen(
            onListening = {
                orb.scaleX = 1.12f
                orb.scaleY = 1.12f
                showBubble("বলুন, শুনছি…")
            },
            onResult = { spoken ->
                showBubble("ভাবছি: $spoken")
                serviceScope.launch {
                    try {
                        val reply = apiClient.askJarvis(spoken)
                        showBubble(reply, 9000L)
                        voiceManager.speak(reply) {
                            resetOrb(orb)
                        }
                    } catch (e: Exception) {
                        showBubble(e.message ?: "ত্রুটি হয়েছে", 4500L)
                        resetOrb(orb)
                    }
                }
            },
            onError = { err ->
                showBubble(err, 3000L)
                resetOrb(orb)
            }
        )
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        uiHandler.removeCallbacksAndMessages(null)
        orbView?.let { windowManager.removeView(it) }
        bubbleView?.let { windowManager.removeView(it) }
        voiceManager.destroy()
        serviceScope.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
